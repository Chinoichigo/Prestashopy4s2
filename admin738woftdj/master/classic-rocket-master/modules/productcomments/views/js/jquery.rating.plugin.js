/**
* jquery.rating.plugin.js
 */
