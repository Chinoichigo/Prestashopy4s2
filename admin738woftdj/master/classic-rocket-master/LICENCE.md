Copyright (c) 2011-2020 Prestarocket (Just Web S.A.R.L.)

By downloading or installing or using the Classic Rocket (the "Theme"), you consent to the terms and conditions of this license on behalf of yourself and the company on whose behalf you will use the Theme provided under this license.


The use of the Theme is permitted provided that the following conditions are met:

You can:
- Customize the Theme
- Use the Theme for personal and client projects

You cannot:
- Use in derivative PrestaShop themes that anyone can download for sale or for free.
- Use any of the components included in the Theme in a project that is not built upon the Theme

Classic Rocket Theme (THE "SOFTWARE") ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
